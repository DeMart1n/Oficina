package Oficina;

class Onibus extends Veiculo {
    public Onibus() {
    }
}
