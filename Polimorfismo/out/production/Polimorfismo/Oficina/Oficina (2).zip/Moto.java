package Oficina;

class Moto extends Veiculo {
    public Moto() {
    }
}
