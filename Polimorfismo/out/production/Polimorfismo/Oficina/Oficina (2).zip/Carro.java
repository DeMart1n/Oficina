package Oficina;

class Carro extends Veiculo {
    public Carro() {
    }
}
